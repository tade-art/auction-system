rm *.class
javac *.java
zip -r Submission.zip *