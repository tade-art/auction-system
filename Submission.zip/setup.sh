# SCRIPT THAT CAN ONLY BE RAN ON UNBUNTU WITH ZIP INSTALLED
rm *.class
javac *.java
zip -r Submission.zip *
