# Mini script to clear all .class files from the directories
rm *.class
#rm Submission.zip

# Mini script to automate compilation and movement of java files - hardcoded; will need to be changed as system is worked on
javac *.java

# After compilation, zip the entire content (Java files, class files, and shell scripts) into Submission.zip
#cd ..
zip -r Submission.zip *
