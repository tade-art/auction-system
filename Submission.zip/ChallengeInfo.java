public class ChallengeInfo implements java.io.Serializable {
    byte response[];
    String serverChallenge;
}