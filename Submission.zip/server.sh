rmiregistry & sleep 2
java FrontEnd