rmiregistry & sleep 2
java Server