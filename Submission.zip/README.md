# auction-system
Using Java RMI to create an auction system that can be ran on client nodes
