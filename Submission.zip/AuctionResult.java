public class AuctionResult implements java.io.Serializable {
    String winningEmail;
    int winningPrice;
}