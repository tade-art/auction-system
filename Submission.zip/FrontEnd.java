import java.rmi.RemoteException;
import java.rmi.registry.LocateRegistry;
import java.rmi.registry.Registry;
import java.rmi.server.UnicastRemoteObject;
import java.util.ArrayList;

public class FrontEnd implements Auction {
    protected static ArrayList<Replica> reps = new ArrayList<>();
    protected static int amountOfReps = 3;

    public static void main(String[] args) throws Exception {
        try {
            FrontEnd s = new FrontEnd();
            String name = "FrontEnd";
            Auction stub = (Auction) UnicastRemoteObject.exportObject(s, 0);
            Registry registry = LocateRegistry.getRegistry();
            registry.rebind(name, stub);

            for (int i = 0; i < amountOfReps; i++) {
                Replica rToAdd = new Replica();
                reps.add(rToAdd);
                System.out.println("Replica " + i + " added.");
            }

            System.out.println("FrontEnd is ready.");
        }

        catch (Exception e) {
            System.err.println("Something went wrong here:");
            e.printStackTrace();
        }
    }

    @Override
    public int register(String email) throws RemoteException {
        throw new UnsupportedOperationException("Unimplemented method 'register'");
    }

    @Override
    public AuctionItem getSpec(int itemID) throws RemoteException {
        throw new UnsupportedOperationException("Unimplemented method 'getSpec'");
    }

    @Override
    public int newAuction(int userID, AuctionSaleItem item) throws RemoteException {
        throw new UnsupportedOperationException("Unimplemented method 'newAuction'");
    }

    @Override
    public AuctionItem[] listItems() throws RemoteException {
        throw new UnsupportedOperationException("Unimplemented method 'listItems'");
    }

    @Override
    public AuctionResult closeAuction(int userID, int itemID) throws RemoteException {
        throw new UnsupportedOperationException("Unimplemented method 'closeAuction'");
    }

    @Override
    public boolean bid(int userID, int itemID, int price) throws RemoteException {
        throw new UnsupportedOperationException("Unimplemented method 'bid'");
    }

    @Override
    public int getPrimaryReplicaID() throws RemoteException {
        throw new UnsupportedOperationException("Unimplemented method 'getPrimaryReplicaID'");
    }

}
