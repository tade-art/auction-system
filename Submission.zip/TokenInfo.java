public class TokenInfo implements java.io.Serializable {
    String token;
    long expiryTime;
}